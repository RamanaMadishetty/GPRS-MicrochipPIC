
#ifndef _DELAY_H_
#define _DELAY_H_

void DELAY_sec(unsigned int count);
void DELAY_us(unsigned int count);
void DELAY_ms(unsigned int count);

#endif
