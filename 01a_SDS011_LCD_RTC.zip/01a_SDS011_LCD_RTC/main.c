#include<lpc17xx.h>
#include "lcd.h"    //User defined LCD library which contains the lcd routines
#include "delay.h"  //User defined library which contains the delay routines
#include "uart.h"  
#include "rtc.h"      

uint16_t Pm25,Pm10;
float finalPm25,finalPm10;


int main()
{
  uint8_t mData = 0;
  uint8_t i = 0;
  uint8_t mPkt[10] = {0};
  uint8_t mCheck = 0;

	rtc_t rtc;

    SystemInit();                              //Clock and PLL configuration

   /* Setup/Map the controller pins for LCD operation, In 4bit mode D0-D3 are P_NC(Not Connected)
               RS   RW    EN  D0   D1   D2   D3   D4    D5    D6    D7*/
    LCD_SetUp(P2_6,P2_7,P2_8,P_NC,P_NC,P_NC,P_NC,P0_24,P0_25,P0_26,P0_27);

  /* Specify the LCD type(2x16, 4x16 etc) for initialization*/
    LCD_Init(2,16);

	    RTC_Init();

    rtc.hour = 10; //  4:20:20 am
    rtc.min =  0;
    rtc.sec =  0;

    rtc.date = 12; //11 july 2017
    rtc.month = 7;
    rtc.year = 2017;
    rtc.weekDay = 3; // Tuesday: 5th day of week considering monday as first day.

  /* Initialize All the Four UARTs with different Baud rate */
    UART0_Init(9600);   
    UART1_Init(9600);   
 
   /*scroll the message on line1 */
    LCD_Clear();
    LCD_ScrollMessage(1,"          Skymet Weather Services");
  
    LCD_Clear();
    LCD_Printf("Welcome,\nAWS Network");
    DELAY_sec(3);     

	UART0_Printf("channel Zero at 9600 baud\n\r"); 

	    /*##### Set the time and Date only once. Once the Time and Date is set, comment these lines
         and reflash the code. Else the time will be set every time the controller is reset*/
  //  RTC_SetDateTime(&rtc);  //  10:40:20 am, 1st Jan 2016

   while (1){    
    // packet format: AA   C0   PM25_Low   PM25_High   PM10_Low   PM10_High   0   0   CRC   AB
 	RTC_GetDateTime(&rtc);

    mData = UART1_RxChar();     
    DELAY_ms(2);   
	                                // wait until packet is received
      if (mData == 0xAA){               // head1 ok
			mPkt[0] =  mData;
			mData = UART1_RxChar(); 
			if (mData == 0xc0){           // head2 ok
				mPkt[1] =  mData;
   		   		mCheck = 0;
      			for (i = 0; i < 6; i++){           // data recv and crc calc
       				mPkt[i + 2] = UART1_RxChar();  	
       				DELAY_ms(2);
       				mCheck += mPkt[i + 2];
     				}
       			mPkt[8] = UART1_RxChar(); 
       			DELAY_ms(1);
       			mPkt[9] = UART1_RxChar(); 
        		if (mCheck == mPkt[8]){        // crc ok
//		LPC_UART1->FCR = (1<<SBIT_FIFO) | (1<<SBIT_RxFIFO) | (1<<SBIT_TxFIFO); // Enable FIFO and reset Rx/Tx FIFO buffers   
		   
        		Pm25 = (uint16_t)mPkt[2] | (uint16_t)(mPkt[3] << 8);
        		Pm10 = (uint16_t)mPkt[4] | (uint16_t)(mPkt[5] << 8);

				finalPm25 =	 Pm25/10.00;
				finalPm10 =	 Pm10/10.00;
			//	LCD_Printf("time:%2d:%2d:%2d  \nDate:%2d/%2d/%4d",(uint16_t)rtc.hour,(uint16_t)rtc.min,(uint16_t)rtc.sec,(uint16_t)rtc.date,(uint16_t)rtc.month,(uint16_t)rtc.year);
				UART0_Printf("time:%2d:%2d:%2d  Date:%2d/%2d/%4d  PM2.5=%2f  PM10=%2f\n\r",(uint16_t)rtc.hour,(uint16_t)rtc.min,(uint16_t)rtc.sec,(uint16_t)rtc.date,(uint16_t)rtc.month,(uint16_t)rtc.year,finalPm25,finalPm10);
			//	UART0_Printf("%2d:%2d:%2d  %2f  %2f\n\r",(uint16_t)rtc.hour,(uint16_t)rtc.min,(uint16_t)rtc.sec,finalPm25,finalPm10);
				LCD_Clear();
				LCD_Printf("PM25:%2f ug/m3\nPM10:%2f ug/m3\n\r",finalPm25,finalPm10);
 				mData =0;
        		}
      		}
    	}
  	}
}

